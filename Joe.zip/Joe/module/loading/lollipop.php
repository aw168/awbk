<!-- 七彩棒棒糖 -->
<div id="loading-animation">
	<div id="loading-animation-center"><div id="loading-animation-center-absolute"><div class="loading_object" id="loading_four"></div><div class="loading_object" id="loading_three"></div><div class="loading_object" id="loading_two"></div><div class="loading_object" id="loading_one"></div></div></div>
</div>