<!-- 原神启动 -->
<div id="loading-animation"></div>